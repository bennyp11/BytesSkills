---
name: bytes
description: Entry point for the BytesSkills content workflow library. Interpret /bytes commands and explicit requests to use BytesSkills, including progressive clipping, help and Git synchronization. Do not intercept unrelated plugins or generic help/sync requests outside BytesSkills.
---

# BytesSkills

Use `/bytes <command> [parameters]` as the canonical assistant-facing language.
This skill is the single entry point; read relevant references directly rather than
asking the user to invoke additional skills. Do not execute the command text as a
shell command. Native host invocation may differ; these aliases do not register a
terminal executable or guarantee a slash-menu entry on every platform.

## Connected workspace: begin every request

For connected BytesSkills tools, read [version/adoption instructions](references/versions.md).
Call `bytes_begin` at the start of every new `/bytes` request, including help. Follow
its pinned instructions/resources; ask about new releases when it returns
`update_available`. Never use a remembered instruction version to bypass this check.
Read [cloud guidance](references/cloud.md) for artifact operations. Saves require the
returned workflow_id. If tools are unavailable, explain that the cloud workflow is
unavailable; never silently switch a remote workspace to local storage.

`/bytes help`, `/bytes --help` and bare `/bytes` are aliases. Help does not generate
content or mutate artifacts. Unknown commands get help rather than another plugin.

```text
/bytes help
/bytes brainstorm --concepts --format=reductions
/bytes refine --hook=@hook/<UUID> --req="Make it more personal"
/bytes sync --check
/bytes sync --latest
/bytes sync --git --check
```

`sync --latest` adopts all current compatible skill releases in one operation;
`sync --check` only reports updates. Git sync requires `--git` and local tools.
These adoption-control commands must still be usable when the sync skill itself has
an update pending. See [versions](references/versions.md) for exact tool mapping.

## Explicit local workspaces

Only for explicitly local storage, use [artifact guidance](references/artifacts.md)
and [operation contracts](contracts/operations.json). Read [help](references/help/instructions.md)
for help and [clip](references/clip/instructions.md) for clipping. The local helper
provides artifact history, but does not provide the cloud skill-adoption protocol.
A workspace marked `storage.mode=remote` is a read-only mirror, never a local fallback.
For explicit `/bytes sync --git`, read [Git sync](references/sync/instructions.md).
Do not execute slash-command text in a shell or invent pointers.

## Creative intake and capability boundaries

Unresolved creative fields require one clarifier at a time before generation.
Clear inherited values and settled answers do not need repeating. “Idk” delegates
one choice; “choose everything else” delegates the remaining choices. Help and sync
do not trigger this creative questionnaire.

Other plugins are execution tools a workflow may use when actually available;
they are not stacked user-facing invocations. Check capability and permissions before
using an editor, image generator or other external service. Reading this skill does
not install those tools or grant access to another platform.

After sync, distinguish the updated source checkout, reread instructions in this
chat and any installed or cached plugin. Do not equate source updates with a reload.
